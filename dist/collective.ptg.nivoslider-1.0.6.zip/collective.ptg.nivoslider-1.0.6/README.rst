Introduction
============

Integrate nivo slider (v2.7.1, http://nivo.dev7studios.com/ ) in plonetruegallery

There are a few "extra themes", you might be able to see some of them here:
http://products.medialog.no/galleries/nivoslider-1